package jgame.gradle;

// import processing.core.*;

public interface ObjetoMovible{

	public void update(double delta);
	public double getX();
	public double getY();
}